.. include:: common.txt

:mod:`pygame.time`
==================

.. autopgmodule:: pygame.time
   :members:
