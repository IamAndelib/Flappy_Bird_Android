import unittest


class CameraModuleTest(unittest.TestCase):
    pass
