/* Auto generated file: with make_docs.py .  Docs go in docs/reST/ref/ . */
#define DOC_SDL2_TOUCH "pygame module to work with touch input"
#define DOC_SDL2_TOUCH_GETNUMDEVICES "get_num_devices() -> int\nget the number of touch devices"
#define DOC_SDL2_TOUCH_GETDEVICE "get_device(index) -> touchid\nget the a touch device id for a given index"
#define DOC_SDL2_TOUCH_GETNUMFINGERS "get_num_fingers(touchid) -> int\nthe number of active fingers for a given touch device"
#define DOC_SDL2_TOUCH_GETFINGER "get_finger(touchid, index) -> int\nget information about an active finger"
