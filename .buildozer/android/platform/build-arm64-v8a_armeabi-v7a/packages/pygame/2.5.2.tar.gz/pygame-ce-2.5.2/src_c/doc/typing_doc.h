/* Auto generated file: with make_docs.py .  Docs go in docs/reST/ref/ . */
#define DOC_TYPING "pygame module providing common typehints"
#define DOC_TYPING_FILELIKE ""
#define DOC_TYPING_SEQUENCELIKE ""
#define DOC_TYPING_POINT ""
#define DOC_TYPING_INTPOINT ""
#define DOC_TYPING_COLORLIKE ""
#define DOC_TYPING_RECTLIKE ""
