/* Auto generated file: with make_docs.py .  Docs go in docs/reST/ref/ . */
#define DOC_LOCALS "pygame constants"
