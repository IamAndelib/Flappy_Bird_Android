/* Auto generated file: with make_docs.py .  Docs go in docs/reST/ref/ . */
#define DOC_TESTS "Pygame unit test suite package"
#define DOC_TESTS_RUN "run(*args, **kwds) -> tuple\nRun the pygame unit test suite"
